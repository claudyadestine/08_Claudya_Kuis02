import java.util.Scanner;

public class Main08 {
    public static void main(String[] args) {
        ProgramBuku08 ProgramBuku08 = new ProgramBuku08();
        Penyimpanan08 arrayList = new Penyimpanan08();

        // Menambahkan data awal
        Buku08 b1 = new Buku08("Pemrograman Java", "001", "John Doe");
        Buku08 b2 = new Buku08("Algoritma dan Struktur Data", "002", "Jane Smith");
        Buku08 b3 = new Buku08("Basis Data", "003", "Emily Johnson");
        Buku08 b4 = new Buku08("Jaringan Komputer", "004", "Michael Brown");

        ProgramBuku08.add(b1);
        ProgramBuku08.add(b2);
        ProgramBuku08.add(b3);
        ProgramBuku08.add(b4);

        arrayList.add(b1);
        arrayList.add(b2);
        arrayList.add(b3);
        arrayList.add(b4);

        Scanner scanner = new Scanner(System.in);
        int menu;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Hapus Buku");
            System.out.println("3. Cetak Semua Buku");
            System.out.println("4. Keluar");
            System.out.print("Pilih operasi: ");
            menu = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (menu) {
                case 1:
                    System.out.print("Masukkan judul: ");
                    String judul = scanner.nextLine();
                    System.out.print("Masukkan Nomor Buku: ");
                    String NomorBuku = scanner.nextLine();
                    System.out.print("Masukkan pengarang: ");
                    String pengarang = scanner.nextLine();
                    Buku08 buku = new Buku08(judul, NomorBuku, pengarang);
                    ProgramBuku08.add(buku);
                    arrayList.add(buku);
                    break;
                case 2:
                    System.out.print("Masukkan NomorBuku buku yang ingin dihapus: ");
                    NomorBuku = scanner.nextLine();
                    if (ProgramBuku08.delete(NomorBuku)) {
                        arrayList.delete(NomorBuku);
                        System.out.println("Buku berhasil dihapus.");
                    } else {
                        System.out.println("Buku tidak ditemukan.");
                    }
                    break;
                case 3:
                    System.out.println("Semua Buku:");
                    ProgramBuku08.printAll();
                    break;
                
                case 4:
                    System.out.println("Keluar program.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
        } while (menu != 4);
    }
}
