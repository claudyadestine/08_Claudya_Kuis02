public class Buku08 {
    String judul;
    String NomorBuku;
    String pengarang;

    // Konstruktor default
    public Buku08() {}

    // Konstruktor berparameter
    public Buku08(String judul, String NomorBuku, String pengarang) {
        this.judul = judul;
        this.NomorBuku = NomorBuku;
        this.pengarang = pengarang;
    }
}
