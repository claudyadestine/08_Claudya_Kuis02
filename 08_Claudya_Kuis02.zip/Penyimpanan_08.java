import java.util.ArrayList;
import java.util.Collection;

public class Penyimpanan08 {
    Collection<Buku08> koleksiBuku;

    public Penyimpanan08() {
        koleksiBuku = new ArrayList<>();
    }

    public void add(Buku08 data) {
        koleksiBuku.add(data);
    }

    public boolean delete(String NomorBuku) {
        for (Buku08 b : koleksiBuku) {
            if (b.NomorBuku.equals(NomorBuku)) {
                koleksiBuku.remove(b);
                return true;
            }
        }
        return false;
    }

    public Buku08 get(String NomorBuku) {
        for (Buku08 b : koleksiBuku) {
            if (b.NomorBuku.equals(NomorBuku)) {
                return b;
            }
        }
        return null;
    }
}
