public class ProgramBuku08 {
    class Node {
        Buku08 data;
        Node next;

        Node(Buku08 data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head;

    public ProgramBuku08() {
        head = null;
    }

    public void add(Buku08 data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public boolean delete(String NomorBuku) {
        if (head == null) return false;
        if (head.data.NomorBuku.equals(NomorBuku)) {
            head = head.next;
            return true;
        }

        Node temp = head;
        while (temp.next != null && !temp.next.data.NomorBuku.equals(NomorBuku)) {
            temp = temp.next;
        }

        if (temp.next == null) return false;
        temp.next = temp.next.next;
        return true;
    }

    public Buku08 get(String NomorBuku) {
        Node temp = head;
        while (temp != null) {
            if (temp.data.NomorBuku.equals(NomorBuku)) {
                return temp.data;
            }
            temp = temp.next;
        }
        return null;
    }

    public void printAll() {
        System.out.println("+--------------+------------------------------------------+-------------------+");
        System.out.println("|   No Buku   |                  Judul                   |      Pengarang    |");
        System.out.println("+--------------+------------------------------------------+-------------------+");
        
        Node temp = head;
        while (temp != null) {
            System.out.printf("| %-10s | %-40s | %-17s |\n", temp.data.NomorBuku, temp.data.judul, temp.data.pengarang);
            temp = temp.next;
        }
        
        System.out.println("+--------------+------------------------------------------+-------------------+");
    }
    
}
